package com.leonlab.app

import android.app.Activity
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import org.json.JSONObject
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private val worker = Executors.newSingleThreadExecutor()
    private var pendingInstallUri: Uri? = null
    private var completedDownloadId: Long = -1L

    private val downloadReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action != DownloadManager.ACTION_DOWNLOAD_COMPLETE) return
            val id = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L)
            if (id != completedDownloadId) return
            val manager = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
            val uri = manager.getUriForDownloadedFile(id)
            if (uri == null) {
                Toast.makeText(this@MainActivity, "Не удалось загрузить APK", Toast.LENGTH_LONG).show()
                return
            }
            pendingInstallUri = uri
            beginInstallIfAllowed()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(237, 244, 255)
        window.navigationBarColor = android.graphics.Color.rgb(237, 244, 255)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.decorView.systemUiVisibility = android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
                android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }

        webView = WebView(this)
        webView.setBackgroundColor(android.graphics.Color.rgb(237, 244, 255))
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.settings.setSupportZoom(false)
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = WebViewClient()
        webView.addJavascriptInterface(DownloadBridge(), "AndroidBridge")
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")

        val filter = IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(downloadReceiver, filter, RECEIVER_NOT_EXPORTED)
        else @Suppress("DEPRECATION") registerReceiver(downloadReceiver, filter)
    }

    override fun onResume() {
        super.onResume()
        if (pendingInstallUri != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && packageManager.canRequestPackageInstalls()) {
            beginInstallIfAllowed()
        }
    }

    private fun beginInstallIfAllowed() {
        val uri = pendingInstallUri ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !packageManager.canRequestPackageInstalls()) {
            AlertDialog.Builder(this)
                .setTitle("Разрешение на установку")
                .setMessage("Разреши LEON_LAB устанавливать обновления из этого источника в настройках Android. Это разрешение нужно только для установки скачанного APK.")
                .setPositiveButton("Открыть настройки") { _, _ ->
                    startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")))
                }
                .setNegativeButton("Позже", null)
                .show()
            return
        }
        pendingInstallUri = null
        val installIntent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            startActivity(installIntent)
        } catch (e: Exception) {
            Toast.makeText(this, "Не удалось открыть установщик: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    inner class DownloadBridge {
        @JavascriptInterface
        fun checkForUpdates() {
            runOnUiThread { Toast.makeText(this@MainActivity, "Проверяем обновления…", Toast.LENGTH_SHORT).show() }
            worker.execute {
                try {
                    // Replace YOUR_GITHUB_USERNAME with the account owner after the repository is created.
                    val owner = "YOUR_GITHUB_USERNAME"
                    val repo = "LEON_LAB"
                    val endpoint = "https://api.github.com/repos/$owner/$repo/releases/latest"
                    val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                        connectTimeout = 12000
                        readTimeout = 12000
                        requestMethod = "GET"
                        setRequestProperty("Accept", "application/vnd.github+json")
                        setRequestProperty("User-Agent", "LEON_LAB-Android")
                    }
                    val code = connection.responseCode
                    if (code != 200) throw IllegalStateException("GitHub ответил: HTTP $code. Проверь настройки репозитория.")
                    val response = connection.inputStream.bufferedReader().use { it.readText() }
                    connection.disconnect()
                    val release = JSONObject(response)
                    val tag = release.optString("tag_name", "")
                    val assets = release.optJSONArray("assets") ?: throw IllegalStateException("В релизе нет APK-файлов")
                    var apkUrl: String? = null
                    for (i in 0 until assets.length()) {
                        val asset = assets.getJSONObject(i)
                        if (asset.optString("name").endsWith(".apk", ignoreCase = true)) {
                            apkUrl = asset.optString("browser_download_url")
                            break
                        }
                    }
                    if (tag.isBlank() || apkUrl.isNullOrBlank()) throw IllegalStateException("В последнем релизе не найден APK")
                    val current = packageManager.getPackageInfo(packageName, 0).versionName ?: "0.3.0"
                    runOnUiThread {
                        if (tag.removePrefix("v") == current) {
                            AlertDialog.Builder(this@MainActivity).setTitle("LEON_LAB актуален")
                                .setMessage("Установлена версия $current. Обновлений пока нет.")
                                .setPositiveButton("Хорошо", null).show()
                        } else {
                            AlertDialog.Builder(this@MainActivity).setTitle("Доступно обновление $tag")
                                .setMessage("Сейчас установлена версия $current. Скачать и открыть установщик обновления?")
                                .setPositiveButton("Скачать") { _, _ -> downloadApk(apkUrl, tag) }
                                .setNegativeButton("Отмена", null).show()
                        }
                    }
                } catch (e: Exception) {
                    runOnUiThread {
                        AlertDialog.Builder(this@MainActivity).setTitle("Проверка не удалась")
                            .setMessage(e.message ?: "Нет соединения или репозиторий ещё не настроен.")
                            .setPositiveButton("ОК", null).show()
                    }
                }
            }
        }

        private fun downloadApk(apkUrl: String, tag: String) {
            try {
                val request = DownloadManager.Request(Uri.parse(apkUrl))
                    .setTitle("LEON_LAB $tag")
                    .setDescription("Загрузка обновления приложения")
                    .setMimeType("application/vnd.android.package-archive")
                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "LEON_LAB-$tag.apk")
                    .setAllowedOverMetered(true)
                    .setAllowedOverRoaming(true)
                val manager = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
                completedDownloadId = manager.enqueue(request)
                Toast.makeText(this@MainActivity, "APK загружается. Уведомление появится после завершения.", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "Ошибка загрузки: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }

        @JavascriptInterface
        fun saveBase64File(fileName: String, base64Content: String, mimeType: String) {
            runOnUiThread {
                try {
                    val safeName = fileName.replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "leon_lab_image.png" }
                    val bytes = android.util.Base64.decode(base64Content, android.util.Base64.DEFAULT)
                    val values = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, safeName)
                        put(MediaStore.Downloads.MIME_TYPE, mimeType.ifBlank { "image/png" })
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/LEON_LAB")
                            put(MediaStore.Downloads.IS_PENDING, 1)
                        }
                    }
                    val resolver = contentResolver
                    val uri: Uri? = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    if (uri == null) {
                        Toast.makeText(this@MainActivity, "Не удалось создать файл", Toast.LENGTH_LONG).show()
                        return@runOnUiThread
                    }
                    resolver.openOutputStream(uri)?.use { it.write(bytes) }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        val done = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
                        resolver.update(uri, done, null, null)
                    }
                    Toast.makeText(this@MainActivity, "PNG сохранён в Загрузки/LEON_LAB", Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "Ошибка сохранения PNG: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }

        @JavascriptInterface
        fun saveTextFile(fileName: String, content: String, mimeType: String) {
            runOnUiThread {
                try {
                    val safeName = fileName.replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "leon_lab_export.obj" }
                    val values = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, safeName)
                        put(MediaStore.Downloads.MIME_TYPE, mimeType.ifBlank { "text/plain" })
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/LEON_LAB")
                            put(MediaStore.Downloads.IS_PENDING, 1)
                        }
                    }
                    val resolver = contentResolver
                    val uri: Uri? = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    if (uri == null) {
                        Toast.makeText(this@MainActivity, "Не удалось создать файл", Toast.LENGTH_LONG).show()
                        return@runOnUiThread
                    }
                    resolver.openOutputStream(uri)?.use { out: OutputStream -> out.write(content.toByteArray(Charsets.UTF_8)) }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        val done = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
                        resolver.update(uri, done, null, null)
                    }
                    Toast.makeText(this@MainActivity, "Сохранено в Загрузки/LEON_LAB", Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "Ошибка сохранения: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        webView.evaluateJavascript(
            "(function(){var visible=['3d','archive','ideas','about'].filter(id=>!document.getElementById(id).hidden);if(visible.length&&visible[0]!=='3d'){showSection('3d');return true;}return false;})()"
        ) { result -> if (result != "true") finish() }
    }

    override fun onDestroy() {
        try { unregisterReceiver(downloadReceiver) } catch (_: Exception) { }
        worker.shutdownNow()
        super.onDestroy()
    }
}
