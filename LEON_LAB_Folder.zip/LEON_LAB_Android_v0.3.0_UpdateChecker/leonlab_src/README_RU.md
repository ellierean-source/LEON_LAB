# LEON_LAB Android — v0.3.0

Мобильная творческая лаборатория LEON_LAB: WebView-интерфейс, 3D-цех, цветовой цех, локальный архив проектов и заметки.

## Что нового в 0.3.0

- Добавлена кнопка **«Проверить обновления»** в разделе «О лаборатории».
- Android-приложение проверяет последний GitHub Release через GitHub API.
- Если в релизе опубликован APK, приложение предлагает скачать его через Android Download Manager и открыть системный установщик.
- Установка требует подтверждения Android; приложение не может тихо устанавливать APK.
- Сохранены функции предыдущей версии: WebView, локальное хранилище, экспорт OBJ и PNG.

## Важно: настроить репозиторий обновлений

В `app/src/main/java/com/leonlab/app/MainActivity.kt` найди строки:

```kotlin
val owner = "YOUR_GITHUB_USERNAME"
val repo = "LEON_LAB"
```

Замени `YOUR_GITHUB_USERNAME` на точное имя владельца GitHub-репозитория. Имя репозитория `LEON_LAB` должно совпадать с названием созданного репозитория (или поменяй значение `repo`).

Updater смотрит публичный endpoint:

`https://api.github.com/repos/OWNER/REPO/releases/latest`

Чтобы приложение обнаружило обновление, создай GitHub Release и прикрепи к нему APK, имя которого заканчивается на `.apk`.

## Сборка APK

GitHub Actions workflow `.github/workflows/android-build.yml` собирает debug APK при ручном запуске или push в ветку `main`/`master`. APK появляется в Actions → workflow run → Artifacts.

Для публикации APK в GitHub Releases сначала скачай артефакт и прикрепи его к Release. Workflow сам пока не создаёт Release.

## Подпись APK — важно для обновления поверх установленной версии

Android принимает обновление поверх приложения только если package name и подпись совпадают. `applicationId` проекта: `com.leonlab.app`.

Debug-сборки на разных GitHub runners могут иметь разные debug signing keys. Поэтому **не используй случайные debug APK как постоянный канал обновлений**. Перед публикацией релизного обновления нужно настроить постоянный keystore и хранить его безопасно (например, в GitHub Actions Secrets); потеря ключа может лишить возможности обновлять приложение поверх старой установки.

## Технические параметры

- Version name: `0.3.0`
- Version code: `4`
- minSdk: 29 (Android 10+)
- compileSdk / targetSdk: 35
- Namespace / applicationId: `com.leonlab.app`
- Java: 17

## Сборка локально

Открой проект в Android Studio или используй Gradle 8.9 и Android SDK Platform 35:

```bash
gradle --no-daemon assembleDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`
